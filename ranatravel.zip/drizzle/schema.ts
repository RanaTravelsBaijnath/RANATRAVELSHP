import { boolean, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/** Core user table backing the starter's Manus OAuth flow. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

/** Only entries created by the site administrator can appear in the public route list. */
export const localRoutes = mysqlTable("local_routes", {
  id: int("id").autoincrement().primaryKey(),
  origin: varchar("origin", { length: 160 }).notNull(),
  destination: varchar("destination", { length: 160 }).notNull(),
  departureTime: varchar("departureTime", { length: 160 }),
  fare: varchar("fare", { length: 100 }),
  notes: text("notes"),
  isAvailable: boolean("isAvailable").default(true).notNull(),
  isPublished: boolean("isPublished").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

/** Opaque admin session tokens are hashed before persistence. */
export const adminSessions = mysqlTable("admin_sessions", {
  tokenHash: varchar("tokenHash", { length: 64 }).primaryKey(),
  csrfHash: varchar("csrfHash", { length: 64 }).notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type LocalRoute = typeof localRoutes.$inferSelect;
export type InsertLocalRoute = typeof localRoutes.$inferInsert;
