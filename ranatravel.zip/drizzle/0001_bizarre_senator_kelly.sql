CREATE TABLE `admin_sessions` (
	`tokenHash` varchar(64) NOT NULL,
	`csrfHash` varchar(64) NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `admin_sessions_tokenHash` PRIMARY KEY(`tokenHash`)
);
--> statement-breakpoint
CREATE TABLE `local_routes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`origin` varchar(160) NOT NULL,
	`destination` varchar(160) NOT NULL,
	`departureTime` varchar(160),
	`fare` varchar(100),
	`notes` text,
	`isAvailable` boolean NOT NULL DEFAULT true,
	`isPublished` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `local_routes_id` PRIMARY KEY(`id`)
);
