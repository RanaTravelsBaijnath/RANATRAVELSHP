import { useEffect, useState } from "react";
import { ArrowDown, ArrowRight, ArrowUpRight, BusFront, Clock3, MapPin, Phone, Route as RouteIcon } from "lucide-react";

type PublishedRoute = {
  id: number;
  origin: string;
  destination: string;
  departureTime: string | null;
  fare: string | null;
  notes: string | null;
  isAvailable: boolean;
};

const socialLinks = {
  instagram: "https://www.instagram.com/ranatravels_/",
  facebook: "https://www.facebook.com/p/RAnA-BuS-Transport-BaijNath-100082062084095/",
};

function BrandMark({ light = false }: { light?: boolean }) {
  return (
    <a className={`brand-mark${light ? " brand-mark-light" : ""}`} href="/" aria-label="Rana Travels home">
      <img className="brand-logo-image" src="/manus-storage/rana-travels-logo_a7928d62.jpg" alt="" />
      <span className="brand-wording"><strong>Rana Travels</strong><small>BAIJNATH · HIMACHAL</small></span>
    </a>
  );
}

function PhoneAction({ number, label }: { number: string; label?: string }) {
  return <a href={`tel:${number.replace(/\s/g, "")}`} className="phone-action"><Phone size={16} aria-hidden="true" /><span>{label ?? number}</span></a>;
}

export default function Home() {
  const [routes, setRoutes] = useState<PublishedRoute[]>([]);
  const [routeState, setRouteState] = useState<"loading" | "ready" | "error">("loading");

  useEffect(() => {
    let mounted = true;
    fetch("/api/routes", { credentials: "same-origin" })
      .then(async response => {
        if (!response.ok) throw new Error("Route updates could not be loaded.");
        return response.json() as Promise<{ routes: PublishedRoute[] }>;
      })
      .then(data => {
        if (!mounted) return;
        setRoutes(data.routes);
        setRouteState("ready");
      })
      .catch(() => { if (mounted) setRouteState("error"); });
    return () => { mounted = false; };
  }, []);

  return (
    <div className="site-shell">
      <div className="topline"><span>Local bus service · Baijnath, Himachal Pradesh</span><a href="#contact">Enquiries <ArrowRight size={13} /></a></div>
      <header className="site-header">
        <BrandMark />
        <nav className="main-nav" aria-label="Main navigation">
          <a href="#about">About</a><a href="#routes">Route updates</a><a href="#contact">Contact</a>
        </nav>
        <a className="button button-dark header-call" href="tel:+919129300022"><Phone size={16} /> Call Rana Travels</a>
      </header>

      <main>
        <section className="hero" aria-labelledby="hero-title">
          <div className="hero-copy">
            <div className="eyebrow"><span className="eyebrow-dot" /> BAIJNATH · HIMACHAL PRADESH</div>
            <h1 id="hero-title">A local bus service <em>from Baijnath.</em></h1>
            <p>Rana Bus Service is based in Baijnath, Himachal Pradesh. For current travel details, talk to the team directly.</p>
            <div className="hero-actions">
              <a href="tel:+919129300022" className="button button-amber">Call for details <ArrowRight size={17} /></a>
              <a href="#routes" className="text-link">See route updates <ArrowDown size={15} /></a>
            </div>
            <div className="hero-note"><BusFront size={18} /><span>For enquiries and bookings, contact Rana Travels directly.</span></div>
          </div>
          <div className="hero-visual">
            <img src="/manus-storage/images(3)_899ce5b4.jpg" alt="Rana-branded passenger coach on a road against a mountain backdrop" />
          </div>
        </section>

        <div className="journey-rule" aria-hidden="true"><span /><i /><span /><i /><span /></div>

        <section className="routes-section section-wrap" id="routes" aria-labelledby="routes-title">
          <div className="section-kicker"><RouteIcon size={16} /> ROUTE BOARD</div>
          <div className="section-heading-row">
            <div><h2 id="routes-title">Route updates</h2><p>Details appear here only after Rana Travels adds and publishes them.</p></div>
            <span className="live-tag"><span /> ADMIN-UPDATED</span>
          </div>
          {routeState === "loading" && <div className="route-empty"><div className="empty-icon"><Clock3 /></div><p>Checking for published route updates…</p></div>}
          {routeState === "error" && <div className="route-empty"><div className="empty-icon"><Clock3 /></div><p>Route updates are temporarily unavailable. Please call Rana Travels for current information.</p><a href="tel:+919129300022" className="text-link">Call the team <ArrowRight size={15} /></a></div>}
          {routeState === "ready" && routes.length === 0 && <div className="route-empty"><div className="empty-icon"><MapPin /></div><h3>No routes posted here yet.</h3><p>We don’t list routes until Rana Travels publishes confirmed details. Call the team for current information.</p><a href="tel:+919129300022" className="text-link">Ask by phone <ArrowRight size={15} /></a></div>}
          {routeState === "ready" && routes.length > 0 && <div className="routes-list">{routes.map(route => (
            <article className="route-card" key={route.id}>
              <div className="route-card-top"><span className="route-chip">LOCAL ROUTE</span><span className={`availability ${route.isAvailable ? "is-available" : "is-unavailable"}`}>{route.isAvailable ? "Availability confirmed by admin" : "Check availability"}</span></div>
              <div className="route-journey"><strong>{route.origin}</strong><span className="route-dash"><i /></span><strong>{route.destination}</strong></div>
              <div className="route-facts">{route.departureTime && <span><Clock3 size={15} />{route.departureTime}</span>}{route.fare && <span>Fare: {route.fare}</span>}</div>
              {route.notes && <p className="route-notes">{route.notes}</p>}
              <a className="route-enquire" href="tel:+919129300022">Enquire <ArrowUpRight size={15} /></a>
            </article>
          ))}</div>}
          <a href="/admin" className="admin-entry">Route administrator <ArrowUpRight size={13} /></a>
        </section>

        <section className="about-band" id="about">
          <div className="about-inner section-wrap">
            <div className="about-symbol" aria-hidden="true"><BusFront size={34} /><span /></div>
            <div className="about-copy"><div className="section-kicker">A LOCAL CONNECTION</div><h2>Rooted in Baijnath.<br /><em>Ready to hear from you.</em></h2><p>Rana Travels identifies itself as a bus service in Baijnath, Himachal Pradesh. For route, timing, and booking questions, please contact the team directly.</p></div>
            <a href={socialLinks.instagram} target="_blank" rel="noreferrer" className="about-social">Follow the journey <ArrowUpRight size={16} /></a>
          </div>
        </section>

        <section className="contact-section section-wrap" id="contact">
          <div className="contact-intro"><div className="section-kicker"><Phone size={15} /> CONTACT RANA TRAVELS</div><h2>Let’s talk<br /><em>travel details.</em></h2><p>Contact numbers and email below are listed on Rana Travels’ public social profiles.</p></div>
          <div className="contact-details">
            <span className="contact-label">CALL THE TEAM</span>
            <PhoneAction number="+91 91293 00022" />
            <PhoneAction number="+91 91293 00044" />
            <PhoneAction number="+91 70189 99097" />
            <span className="contact-label email-label">EMAIL</span>
            <a className="email-link" href="mailto:info@ranatransport.com">info@ranatransport.com <ArrowUpRight size={14} /></a>
          </div>
          <div className="social-card"><span className="contact-label">FIND US ONLINE</span><a href={socialLinks.instagram} target="_blank" rel="noreferrer">Instagram <ArrowUpRight size={15} /></a><a href={socialLinks.facebook} target="_blank" rel="noreferrer">Facebook <ArrowUpRight size={15} /></a><small>Rana Travels Official · Baijnath, H.P.</small></div>
        </section>
      </main>

      <footer className="site-footer"><BrandMark light /><span>Information shown here is based on Rana Travels’ public social profiles. Please confirm current details directly.</span><a href="/admin">Admin login</a><small>© {new Date().getFullYear()} Rana Travels Baijnath</small></footer>
    </div>
  );
}
