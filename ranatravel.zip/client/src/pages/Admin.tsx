import { useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, BusFront, Check, Eye, EyeOff, LoaderCircle, LogOut, MapPin, Plus, Save, Trash2 } from "lucide-react";
import { Link } from "wouter";
import type { FormEvent } from "react";

type LocalRoute = {
  id: number;
  origin: string;
  destination: string;
  departureTime: string | null;
  fare: string | null;
  notes: string | null;
  isAvailable: boolean;
  isPublished: boolean;
};

type RouteDraft = {
  origin: string;
  destination: string;
  departureTime: string;
  fare: string;
  notes: string;
  isAvailable: boolean;
  isPublished: boolean;
};

const blankDraft: RouteDraft = { origin: "", destination: "", departureTime: "", fare: "", notes: "", isAvailable: true, isPublished: false };

async function api<T>(url: string, options: RequestInit = {}, csrfToken?: string): Promise<T> {
  const response = await fetch(url, { ...options, credentials: "same-origin", headers: { "Content-Type": "application/json", ...(csrfToken ? { "X-Rana-CSRF": csrfToken } : {}), ...(options.headers ?? {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error ?? "Something went wrong. Please try again.");
  return data as T;
}

function AdminBrand() {
  return <Link href="/" className="admin-brand"><img className="admin-brand-logo" src="/manus-storage/rana-travels-logo_a7928d62.jpg" alt="" /><span><strong>Rana Travels</strong><small>ROUTE ADMINISTRATION</small></span></Link>;
}

export default function Admin() {
  const [checking, setChecking] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);
  const [routes, setRoutes] = useState<LocalRoute[]>([]);
  const [csrfToken, setCsrfToken] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState<RouteDraft>(blankDraft);
  const [editingId, setEditingId] = useState<number | null>(null);

  async function loadRoutes() {
    const data = await api<{ routes: LocalRoute[] }>("/api/admin/routes");
    setRoutes(data.routes);
  }

  useEffect(() => {
    let active = true;
    api<{ authenticated: boolean; csrfToken?: string }>("/api/admin/session")
      .then(async data => {
        if (!active) return;
        setAuthenticated(data.authenticated);
        setCsrfToken(data.csrfToken ?? "");
        if (data.authenticated) {
          const result = await api<{ routes: LocalRoute[] }>("/api/admin/routes");
          if (active) setRoutes(result.routes);
        }
      })
      .catch(() => { if (active) setError("Could not check the administrator session. Reload to try again."); })
      .finally(() => { if (active) setChecking(false); });
    return () => { active = false; };
  }, []);

  async function signIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const session = await api<{ csrfToken: string }>("/api/admin/login", { method: "POST", body: JSON.stringify({ email, password }) }, csrfToken);
      setCsrfToken(session.csrfToken);
      setAuthenticated(true);
      setPassword("");
      await loadRoutes();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Sign-in failed.");
    } finally {
      setBusy(false);
    }
  }

  async function signOut() {
    await api("/api/admin/logout", { method: "POST" }, csrfToken).catch(() => undefined);
    setAuthenticated(false);
    setCsrfToken("");
    setRoutes([]);
    setError("");
  }

  function startEdit(route: LocalRoute) {
    setEditingId(route.id);
    setDraft({
      origin: route.origin,
      destination: route.destination,
      departureTime: route.departureTime ?? "",
      fare: route.fare ?? "",
      notes: route.notes ?? "",
      isAvailable: route.isAvailable,
      isPublished: route.isPublished,
    });
    setError("");
    document.getElementById("route-form")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function resetDraft() {
    setEditingId(null);
    setDraft(blankDraft);
    setError("");
  }

  async function saveRoute(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!draft.origin.trim() || !draft.destination.trim()) {
      setError("Add both a starting point and destination.");
      return;
    }
    setBusy(true);
    setError("");
    const payload = JSON.stringify({ ...draft, origin: draft.origin.trim(), destination: draft.destination.trim() });
    try {
      if (editingId) await api(`/api/admin/routes/${editingId}`, { method: "PATCH", body: payload }, csrfToken);
      else await api("/api/admin/routes", { method: "POST", body: payload }, csrfToken);
      await loadRoutes();
      resetDraft();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Could not save this route.");
    } finally {
      setBusy(false);
    }
  }

  async function togglePublished(route: LocalRoute) {
    setBusy(true);
    setError("");
    try {
      await api(`/api/admin/routes/${route.id}`, { method: "PATCH", body: JSON.stringify({
        origin: route.origin,
        destination: route.destination,
        departureTime: route.departureTime ?? "",
        fare: route.fare ?? "",
        notes: route.notes ?? "",
        isAvailable: route.isAvailable,
        isPublished: !route.isPublished,
      }) }, csrfToken);
      await loadRoutes();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Could not update publication status.");
    } finally {
      setBusy(false);
    }
  }

  async function removeRoute(route: LocalRoute) {
    if (!window.confirm(`Delete the route ${route.origin} → ${route.destination}?`)) return;
    setBusy(true);
    setError("");
    try {
      await api(`/api/admin/routes/${route.id}`, { method: "DELETE" }, csrfToken);
      await loadRoutes();
      if (editingId === route.id) resetDraft();
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : "Could not delete this route.");
    } finally {
      setBusy(false);
    }
  }

  if (checking) return <div className="admin-screen"><div className="admin-loading"><LoaderCircle className="spin" />Checking admin access…</div></div>;

  if (!authenticated) return (
    <div className="admin-screen">
      <header className="admin-topbar"><AdminBrand /><Link href="/" className="admin-back"><ArrowLeft size={15} /> Back to website</Link></header>
      <main className="login-layout">
        <section className="login-aside"><div className="login-stamp"><BusFront size={31} /></div><p className="section-kicker">RANA TRAVELS · BAIJNATH</p><h1>Route details,<br /><em>kept by you.</em></h1><p>Sign in to add and maintain the local route information shown to visitors.</p><div className="login-aside-foot"><MapPin size={15} /> Himachal Pradesh</div></section>
        <section className="login-card"><div className="section-kicker">ADMINISTRATOR ACCESS</div><h2>Sign in</h2><p>Use the administrator login to manage route updates.</p>
          <form onSubmit={signIn} className="login-form">
            <label htmlFor="admin-email">Email address</label><input id="admin-email" type="email" autoComplete="username" required value={email} onChange={event => setEmail(event.target.value)} placeholder="Admin email" />
            <label htmlFor="admin-password">Password</label><div className="password-wrap"><input id="admin-password" type={showPassword ? "text" : "password"} autoComplete="current-password" required value={password} onChange={event => setPassword(event.target.value)} placeholder="Enter your password" /><button type="button" className="password-toggle" aria-label={showPassword ? "Hide password" : "Show password"} onClick={() => setShowPassword(value => !value)}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button></div>
            {error && <div className="form-error" role="alert">{error}</div>}
            <button className="button button-dark login-button" type="submit" disabled={busy}>{busy ? <LoaderCircle className="spin" size={17} /> : null} Sign in <ArrowRight size={16} /></button>
          </form>
          <div className="login-safety"><span /><p>Protected administrator area. Visitor route access is read-only.</p></div>
        </section>
      </main>
      <footer className="admin-footer"><Link href="/">Rana Travels Baijnath</Link><span>Private route administration</span></footer>
    </div>
  );

  return (
    <div className="admin-screen manager-screen">
      <header className="admin-topbar"><AdminBrand /><div className="admin-top-actions"><Link href="/" className="admin-back"><ArrowLeft size={15} /> View website</Link><button className="logout-button" onClick={signOut}><LogOut size={15} /> Sign out</button></div></header>
      <main className="manager-main">
        <div className="manager-heading"><div><p className="section-kicker">PRIVATE ADMINISTRATOR AREA</p><h1>Route manager</h1><p>Add only current, verified route information. Nothing appears on the public site until you publish it.</p></div><span className="manager-count">{routes.length} {routes.length === 1 ? "ENTRY" : "ENTRIES"}</span></div>
        <div className="manager-grid">
          <section className="route-editor" id="route-form"><div className="editor-head"><span className="editor-icon"><Plus size={18} /></span><div><h2>{editingId ? "Edit route details" : "Add a local route"}</h2><p>Only details entered here can appear publicly.</p></div></div>
            <form className="route-form" onSubmit={saveRoute}>
              <div className="form-row"><div className="field"><label htmlFor="route-origin">Starting point <b>*</b></label><input id="route-origin" value={draft.origin} onChange={event => setDraft({ ...draft, origin: event.target.value })} placeholder="Enter a verified starting point" required maxLength={160} /></div><div className="field"><label htmlFor="route-destination">Destination <b>*</b></label><input id="route-destination" value={draft.destination} onChange={event => setDraft({ ...draft, destination: event.target.value })} placeholder="Enter a verified destination" required maxLength={160} /></div></div>
              <div className="form-row"><div className="field"><label htmlFor="route-time">Departure / timing <small>OPTIONAL</small></label><input id="route-time" value={draft.departureTime} onChange={event => setDraft({ ...draft, departureTime: event.target.value })} placeholder="Add timing if confirmed" maxLength={160} /></div><div className="field"><label htmlFor="route-fare">Fare <small>OPTIONAL</small></label><input id="route-fare" value={draft.fare} onChange={event => setDraft({ ...draft, fare: event.target.value })} placeholder="Add fare if confirmed" maxLength={100} /></div></div>
              <div className="field"><label htmlFor="route-notes">Additional notes <small>OPTIONAL</small></label><textarea id="route-notes" value={draft.notes} onChange={event => setDraft({ ...draft, notes: event.target.value })} placeholder="Add important route information for passengers" rows={3} maxLength={4000} /></div>
              <div className="toggle-row"><div><strong>Availability</strong><small>Mark whether passengers should check with you first.</small></div><label className="switch-label"><input type="checkbox" checked={draft.isAvailable} onChange={event => setDraft({ ...draft, isAvailable: event.target.checked })} /><span>{draft.isAvailable ? "Available" : "Check first"}</span></label></div>
              <div className="toggle-row publish-row"><div><strong>Publish on website</strong><small>Only published routes are visible to visitors.</small></div><label className="switch-label"><input type="checkbox" checked={draft.isPublished} onChange={event => setDraft({ ...draft, isPublished: event.target.checked })} /><span>{draft.isPublished ? "Published" : "Draft"}</span></label></div>
              {error && <div className="form-error" role="alert">{error}</div>}
              <div className="editor-actions"><button type="submit" className="button button-dark" disabled={busy}>{busy ? <LoaderCircle size={16} className="spin" /> : <Save size={16} />}{editingId ? "Save changes" : "Add route"}</button>{editingId && <button type="button" className="cancel-edit" onClick={resetDraft}>Cancel edit</button>}</div>
            </form>
          </section>
          <section className="route-inventory"><div className="inventory-head"><div><div className="section-kicker">ROUTE RECORDS</div><h2>Your local routes</h2></div><span className="record-count">{routes.length}</span></div>
            {routes.length === 0 ? <div className="inventory-empty"><MapPin size={23} /><h3>No routes added yet</h3><p>Once you add a route, it will be stored here as a draft or published update.</p></div> : <div className="inventory-list">{routes.map(route => <article className="inventory-card" key={route.id}>
              <div className="inventory-card-top"><span className={`publish-badge ${route.isPublished ? "published" : "draft"}`}><i />{route.isPublished ? "Published" : "Draft"}</span><span className="availability-small">{route.isAvailable ? "Availability set" : "Check first"}</span></div>
              <div className="inventory-journey"><strong>{route.origin}</strong><span /> <strong>{route.destination}</strong></div>
              <div className="inventory-extra">{route.departureTime && <span>{route.departureTime}</span>}{route.fare && <span>{route.fare}</span>}</div>
              <div className="inventory-actions"><button onClick={() => startEdit(route)} className="inventory-action">Edit</button><button onClick={() => togglePublished(route)} className="inventory-action" disabled={busy}>{route.isPublished ? <><EyeOff size={14} /> Unpublish</> : <><Eye size={14} /> Publish</>}</button><button onClick={() => removeRoute(route)} className="inventory-action delete-action" disabled={busy}><Trash2 size={14} /> Delete</button></div>
            </article>)}</div>}
            <div className="privacy-note"><Check size={15} /><span>Visitors see published route details only. Your sign-in credentials are never displayed here.</span></div>
          </section>
        </div>
      </main>
      <footer className="admin-footer"><Link href="/">Rana Travels Baijnath</Link><span>Route updates are managed by the administrator</span></footer>
    </div>
  );
}
