import { createHash, randomBytes, timingSafeEqual } from "node:crypto";
import type { Express, Request, RequestHandler, Response } from "express";
import { z } from "zod";
import {
  createAdminSession,
  createLocalRoute,
  deleteLocalRoute,
  findAdminSession,
  listAllLocalRoutes,
  listPublishedRoutes,
  removeAdminSession,
  updateAdminSessionCsrf,
  updateLocalRoute,
} from "./db";

const ADMIN_COOKIE = "__Host-rana_admin_session";
const CSRF_COOKIE = "__Host-rana_admin_csrf";
const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const loginAttempts = new Map<string, { count: number; resetAt: number }>();

const LoginInput = z.object({
  email: z.string().trim().email().max(320),
  password: z.string().min(1).max(2048),
});

const RouteInput = z.object({
  origin: z.string().trim().min(1).max(160),
  destination: z.string().trim().min(1).max(160),
  departureTime: z.string().trim().max(160).optional().transform(value => value || null),
  fare: z.string().trim().max(100).optional().transform(value => value || null),
  notes: z.string().trim().max(4000).optional().transform(value => value || null),
  isAvailable: z.boolean().default(true),
  isPublished: z.boolean().default(false),
});

function constantTimeTextEqual(leftText: string, rightText: string) {
  const left = Buffer.from(leftText, "utf8");
  const right = Buffer.from(rightText, "utf8");
  if (left.length !== right.length) {
    const dummy = Buffer.alloc(Math.max(left.length, right.length, 1));
    timingSafeEqual(dummy, dummy);
    return false;
  }
  return timingSafeEqual(left, right);
}

function sha256(value: string) {
  return createHash("sha256").update(value).digest("hex");
}

function readCookie(req: Request, name: string) {
  const cookieHeader = req.headers.cookie;
  if (!cookieHeader) return null;
  for (const entry of cookieHeader.split(";")) {
    const index = entry.indexOf("=");
    if (index < 0) continue;
    if (entry.slice(0, index).trim() === name) return entry.slice(index + 1).trim();
  }
  return null;
}

function secureCookieOptions(maxAge: number) {
  return { httpOnly: true, secure: true, sameSite: "none" as const, path: "/", maxAge };
}

function setAdminCookie(res: Response, token: string) {
  // Preview is HTTPS in a cross-site iframe; Secure + SameSite=None is required there.
  res.cookie(ADMIN_COOKIE, token, secureCookieOptions(SESSION_TTL_MS));
}

function setCsrfCookie(res: Response, token: string) {
  // The token is also returned in same-origin JSON for a custom request header.
  res.cookie(CSRF_COOKIE, token, secureCookieOptions(SESSION_TTL_MS));
}

function clearAdminCookies(res: Response) {
  const options = { httpOnly: true, secure: true, sameSite: "none" as const, path: "/" };
  res.clearCookie(ADMIN_COOKIE, options);
  res.clearCookie(CSRF_COOKIE, options);
}

async function getAdminSession(req: Request) {
  const token = readCookie(req, ADMIN_COOKIE);
  if (!token || token.length > 200) return null;
  return findAdminSession(sha256(token));
}

function validAnonymousCsrf(value: string | null): value is string {
  return Boolean(value && /^[A-Za-z0-9_-]{43}$/.test(value));
}

const asyncRoute = (handler: RequestHandler): RequestHandler => (req, res, next) => {
  Promise.resolve(handler(req, res, next)).catch(next);
};

function requireAdmin(handler: RequestHandler): RequestHandler {
  return asyncRoute(async (req, res, next) => {
    const session = await getAdminSession(req);
    if (!session) {
      res.status(401).json({ error: "Administrator sign-in required." });
      return;
    }
    if (req.method !== "GET") {
      const csrfCookie = readCookie(req, CSRF_COOKIE) ?? "";
      const csrfHeader = req.get("x-rana-csrf") ?? "";
      if (!csrfCookie || !csrfHeader
        || !constantTimeTextEqual(csrfCookie, csrfHeader)
        || !constantTimeTextEqual(sha256(csrfHeader), session.csrfHash)) {
        res.status(403).json({ error: "This administrator request could not be verified. Reload the admin page and try again." });
        return;
      }
    }
    await Promise.resolve(handler(req, res, next));
  });
}

function requestKey(req: Request) {
  return req.ip || "unknown";
}

function isRateLimited(req: Request) {
  const now = Date.now();
  for (const [key, value] of loginAttempts) {
    if (value.resetAt <= now) loginAttempts.delete(key);
  }
  const key = requestKey(req);
  const current = loginAttempts.get(key);
  if (current && current.resetAt > now && current.count >= 10) return true;
  if (!current || current.resetAt <= now) loginAttempts.set(key, { count: 1, resetAt: now + 15 * 60 * 1000 });
  else current.count += 1;
  return false;
}

function resetRateLimit(req: Request) {
  loginAttempts.delete(requestKey(req));
}

function parsedRoute(req: Request, res: Response) {
  const result = RouteInput.safeParse(req.body);
  if (!result.success) {
    res.status(400).json({ error: "Enter a starting point and destination, then review the optional details." });
    return null;
  }
  return result.data;
}

function routeId(req: Request, res: Response) {
  const id = Number(req.params.id);
  if (!Number.isSafeInteger(id) || id < 1) {
    res.status(400).json({ error: "Invalid route entry." });
    return null;
  }
  return id;
}

export function registerAdminRoutes(app: Express) {
  app.get("/api/routes", asyncRoute(async (_req, res) => {
    const routes = await listPublishedRoutes();
    res.setHeader("Cache-Control", "no-store");
    res.json({ routes });
  }));

  app.get("/api/admin/session", asyncRoute(async (req, res) => {
    res.setHeader("Cache-Control", "no-store");
    const session = await getAdminSession(req);
    let csrfToken = readCookie(req, CSRF_COOKIE);
    if (!session) {
      if (!validAnonymousCsrf(csrfToken)) csrfToken = randomBytes(32).toString("base64url");
      setCsrfCookie(res, csrfToken);
      res.json({ authenticated: false, csrfToken });
      return;
    }
    if (!validAnonymousCsrf(csrfToken) || !constantTimeTextEqual(sha256(csrfToken), session.csrfHash)) {
      csrfToken = randomBytes(32).toString("base64url");
      await updateAdminSessionCsrf(session.tokenHash, sha256(csrfToken));
      setCsrfCookie(res, csrfToken);
    }
    res.json({ authenticated: true, csrfToken });
  }));

  app.post("/api/admin/login", asyncRoute(async (req, res) => {
    const csrfCookie = readCookie(req, CSRF_COOKIE) ?? "";
    const csrfHeader = req.get("x-rana-csrf") ?? "";
    if (!validAnonymousCsrf(csrfCookie) || !csrfHeader || !constantTimeTextEqual(csrfCookie, csrfHeader)) {
      res.status(403).json({ error: "This sign-in request could not be verified. Reload the page and try again." });
      return;
    }
    if (isRateLimited(req)) {
      res.status(429).json({ error: "Too many sign-in attempts. Please wait and try again." });
      return;
    }
    const input = LoginInput.safeParse(req.body);
    const expectedEmail = process.env.RANA_ADMIN_EMAIL?.trim().toLowerCase();
    const expectedPassword = process.env.RANA_ADMIN_PASSWORD;
    if (!expectedEmail || !expectedPassword) {
      res.status(503).json({ error: "Administrator sign-in is not configured yet." });
      return;
    }
    const suppliedEmail = input.success ? input.data.email.toLowerCase() : "";
    const suppliedPassword = input.success ? input.data.password : "";
    const matches = constantTimeTextEqual(suppliedEmail, expectedEmail)
      && constantTimeTextEqual(suppliedPassword, expectedPassword);
    if (!matches) {
      res.status(401).json({ error: "The email or password is incorrect." });
      return;
    }
    resetRateLimit(req);
    const token = randomBytes(32).toString("base64url");
    await createAdminSession(sha256(token), sha256(csrfCookie), new Date(Date.now() + SESSION_TTL_MS));
    setAdminCookie(res, token);
    setCsrfCookie(res, csrfCookie);
    res.setHeader("Cache-Control", "no-store");
    res.json({ authenticated: true, csrfToken: csrfCookie });
  }));

  app.post("/api/admin/logout", requireAdmin(async (req, res) => {
    const token = readCookie(req, ADMIN_COOKIE);
    if (token && token.length <= 200) await removeAdminSession(sha256(token));
    clearAdminCookies(res);
    res.json({ success: true });
  }));

  app.get("/api/admin/routes", requireAdmin(async (_req, res) => {
    res.setHeader("Cache-Control", "no-store");
    res.json({ routes: await listAllLocalRoutes() });
  }));

  app.post("/api/admin/routes", requireAdmin(async (req, res) => {
    const route = parsedRoute(req, res);
    if (!route) return;
    await createLocalRoute(route);
    res.status(201).json({ success: true });
  }));

  app.patch("/api/admin/routes/:id", requireAdmin(async (req, res) => {
    const id = routeId(req, res);
    if (id === null) return;
    const route = parsedRoute(req, res);
    if (!route) return;
    await updateLocalRoute(id, route);
    res.json({ success: true });
  }));

  app.delete("/api/admin/routes/:id", requireAdmin(async (req, res) => {
    const id = routeId(req, res);
    if (id === null) return;
    await deleteLocalRoute(id);
    res.json({ success: true });
  }));
}
