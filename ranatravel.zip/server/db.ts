import { and, desc, eq, gt } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { adminSessions, InsertLocalRoute, InsertUser, localRoutes, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

/** Lazily create the Drizzle instance so non-database tooling can run without a DB. */
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

function requireDb(db: Awaited<ReturnType<typeof getDb>>) {
  if (!db) throw new Error("Database is not available");
  return db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = requireDb(await getDb());
  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];
  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listPublishedRoutes() {
  const db = requireDb(await getDb());
  return db.select().from(localRoutes).where(eq(localRoutes.isPublished, true)).orderBy(desc(localRoutes.id));
}

export async function listAllLocalRoutes() {
  const db = requireDb(await getDb());
  return db.select().from(localRoutes).orderBy(desc(localRoutes.id));
}

export async function createLocalRoute(route: InsertLocalRoute) {
  const db = requireDb(await getDb());
  await db.insert(localRoutes).values(route);
}

export async function updateLocalRoute(id: number, route: Partial<InsertLocalRoute>) {
  const db = requireDb(await getDb());
  await db.update(localRoutes).set(route).where(eq(localRoutes.id, id));
}

export async function deleteLocalRoute(id: number) {
  const db = requireDb(await getDb());
  await db.delete(localRoutes).where(eq(localRoutes.id, id));
}

export async function createAdminSession(tokenHash: string, csrfHash: string, expiresAt: Date) {
  const db = requireDb(await getDb());
  await db.insert(adminSessions).values({ tokenHash, csrfHash, expiresAt });
}

export async function findAdminSession(tokenHash: string) {
  const db = requireDb(await getDb());
  const now = new Date();
  const result = await db.select({ tokenHash: adminSessions.tokenHash, csrfHash: adminSessions.csrfHash })
    .from(adminSessions)
    .where(and(eq(adminSessions.tokenHash, tokenHash), gt(adminSessions.expiresAt, now)))
    .limit(1);
  return result[0] ?? null;
}

export async function updateAdminSessionCsrf(tokenHash: string, csrfHash: string) {
  const db = requireDb(await getDb());
  await db.update(adminSessions).set({ csrfHash }).where(eq(adminSessions.tokenHash, tokenHash));
}

export async function removeAdminSession(tokenHash: string) {
  const db = requireDb(await getDb());
  await db.delete(adminSessions).where(eq(adminSessions.tokenHash, tokenHash));
}
